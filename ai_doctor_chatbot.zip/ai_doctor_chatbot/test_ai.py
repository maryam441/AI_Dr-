# test_ai.py
from ai_service import AIService

ai = AIService()
response = ai.chat_completion([
    {"role": "user", "content": "What is hypertension?"}
])
print(response)
