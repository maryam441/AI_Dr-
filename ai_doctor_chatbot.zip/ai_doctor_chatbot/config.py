from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field

class Settings(BaseSettings):
    openrouter_api_key: str = Field(
        default="your-api-key-here",  # Add your actual key here
        env="OPENROUTER_API_KEY",
        description="Get your key from https://openrouter.ai"
    )
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )

settings = Settings()
