import os
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash

class Database:
    def __init__(self):
        self.db_path = os.getenv('DATABASE_PATH', 'database.db')
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.cursor = self.conn.cursor()
        self.create_tables()
        self.create_admin_user()

    def create_tables(self):
        """Create all database tables if they don't exist"""
        self.cursor.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            is_admin BOOLEAN DEFAULT 0,
            last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        
        CREATE TABLE IF NOT EXISTS user_profile (
            user_id INTEGER PRIMARY KEY,
            name TEXT,
            dob TEXT,
            gender TEXT,
            allergies TEXT,
            medications TEXT,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );
        
        CREATE TABLE IF NOT EXISTS chat_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            message TEXT,
            response TEXT,
            is_user_message BOOLEAN,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );
        """)
        self.conn.commit()

    # User management methods
    def get_user_by_name(self, name):
        self.cursor.execute("SELECT * FROM users WHERE name = ?", (name,))
        user = self.cursor.fetchone()
        if user:
            return {
                'id': user[0],
                'name': user[1],
                'password': user[2],
                'is_admin': bool(user[3]),
                'last_active': user[4]
            }
        return None

    def get_user_by_id(self, user_id):
        self.cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
        user = self.cursor.fetchone()
        if user:
            return {
                'id': user[0],
                'name': user[1],
                'password': user[2],
                'is_admin': bool(user[3]),
                'last_active': user[4]
            }
        return None

    def create_admin_user(self):
        admin_name = 'admin'
        admin_password = 'admin_password'

        if not self.get_user_by_name(admin_name):
            hashed_password = generate_password_hash(admin_password, method='pbkdf2:sha256')
            self.cursor.execute(
                "INSERT INTO users (name, password, is_admin) VALUES (?, ?, ?)",
                (admin_name, hashed_password, True)
            )
            self.conn.commit()
            print(f"Admin user '{admin_name}' created.")

    def verify_user_by_name(self, name, password):
        user = self.get_user_by_name(name)
        if user and check_password_hash(user['password'], password):
            return user
        return None

    def create_user(self, name, password):
        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
        self.cursor.execute("INSERT INTO users (name, password) VALUES (?, ?)", (name, hashed_password))
        self.conn.commit()
        return self.cursor.lastrowid

    def update_user_last_active(self, user_id):
        self.cursor.execute("UPDATE users SET last_active = CURRENT_TIMESTAMP WHERE id = ?", (user_id,))
        self.conn.commit()

    # Profile management methods
    def get_user_profile(self, user_id):
        self.cursor.execute(
            "SELECT name, dob, gender, allergies, medications FROM user_profile WHERE user_id = ?",
            (user_id,)
        )
        result = self.cursor.fetchone()
        if result:
            return {
                'name': result[0],
                'dob': result[1],
                'gender': result[2],
                'allergies': result[3],
                'medications': result[4]
            }
        return None

    def update_user_profile(self, user_id, name=None, dob=None, gender=None, allergies=None, medications=None):
        """Update user profile information"""
        profile = self.get_user_profile(user_id) or {}
        
        # Update only provided fields
        updated_profile = {
            'name': name if name is not None else profile.get('name'),
            'dob': dob if dob is not None else profile.get('dob'),
            'gender': gender if gender is not None else profile.get('gender'),
            'allergies': allergies if allergies is not None else profile.get('allergies'),
            'medications': medications if medications is not None else profile.get('medications')
        }

        self.cursor.execute(
            """INSERT OR REPLACE INTO user_profile 
            (user_id, name, dob, gender, allergies, medications) 
            VALUES (?, ?, ?, ?, ?, ?)""",
            (
                user_id,
                updated_profile['name'],
                updated_profile['dob'],
                updated_profile['gender'],
                updated_profile['allergies'],
                updated_profile['medications']
            )
        )
        self.conn.commit()
        return True

    def save_user_profile(self, user_id, profile_data):
        """Alternative method to save complete profile at once"""
        return self.update_user_profile(
            user_id,
            name=profile_data.get('name'),
            dob=profile_data.get('dob'),
            gender=profile_data.get('gender'),
            allergies=profile_data.get('allergies'),
            medications=profile_data.get('medications')
        )

    # Chat history methods
    def get_chat_history(self, user_id, limit=10):
        self.cursor.execute("""
        SELECT * FROM chat_history
        WHERE user_id = ?
        ORDER BY timestamp DESC
        LIMIT ?
        """, (user_id, limit))
        chats = self.cursor.fetchall()
        return [{
            'id': chat[0],
            'user_id': chat[1],
            'message': chat[2],
            'response': chat[3],
            'is_user_message': bool(chat[4]),
            'timestamp': chat[5]
        } for chat in chats]

    def save_chat_message(self, user_id, message, response, is_user_message):
        self.cursor.execute("""
        INSERT INTO chat_history (user_id, message, response, is_user_message)
        VALUES (?, ?, ?, ?)""", (user_id, message, response, is_user_message))
        self.conn.commit()

    # Admin methods
    def get_all_users(self):
        self.cursor.execute("SELECT id, name, is_admin, last_active FROM users")
        return [{
            'id': user[0],
            'name': user[1],
            'is_admin': bool(user[2]),
            'last_active': user[3]
        } for user in self.cursor.fetchall()]

    def close(self):
        self.conn.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()