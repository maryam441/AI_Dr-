document.addEventListener('DOMContentLoaded', function () {
    const chatForm = document.getElementById('chat-form');
    const chatInput = document.getElementById('chat-input');
    const chatMessages = document.getElementById('chat-messages');

    if (chatForm) {
        chatForm.addEventListener('submit', async function (e) {
            e.preventDefault();
            const message = chatInput.value.trim();

            if (message) {
                addMessage(message, 'user');
                chatInput.value = '';
                scrollToBottom();

                try {
                    const response = await fetch('/get-response', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ message }),
                    });

                    const data = await response.json();
                    let cleanResponse = sanitizeText(data.reply || 'Sorry, I could not understand.');
                    addMessage(cleanResponse, 'ai');
                } catch (error) {
                    addMessage('❌ Error contacting the AI. Try again later.', 'ai');
                    console.error('Fetch error:', error);
                }

                scrollToBottom();
            }
        });
    }

    function addMessage(text, sender) {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message', `${sender}-message`);

        const messageText = document.createElement('div');
        messageText.textContent = text;

        const messageTime = document.createElement('div');
        messageTime.classList.add('message-time');
        messageTime.textContent = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

        messageDiv.appendChild(messageText);
        messageDiv.appendChild(messageTime);
        chatMessages.appendChild(messageDiv);
    }

    function scrollToBottom() {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function sanitizeText(text) {
        // Remove repeating lines and trim
        const lines = text.split('\n').map(line => line.trim()).filter(Boolean);
        const uniqueLines = [...new Set(lines)];
        return uniqueLines.join('\n');
    }

    // Load chat history if available
    if (chatMessages && chatMessages.dataset.history) {
        try {
            const history = JSON.parse(chatMessages.dataset.history || '[]');
            history.forEach(msg => {
                addMessage(msg.message || msg.response, msg.is_user_message ? 'user' : 'ai');
            });
            scrollToBottom();
        } catch (e) {
            console.error('Error loading chat history:', e);
            addMessage('Failed to load previous chat history.', 'ai');
        }
    }
});
